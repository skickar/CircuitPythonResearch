# SPDX-FileCopyrightText: 2021 ladyada for Adafruit Industries
# SPDX-License-Identifier: MIT

import time
import board
import adafruit_sht31d
import wifi
import ipaddress
import socketpool



# Create sensor object, communicating over the board's default I2C bus
i2c = board.I2C()
sensor = adafruit_sht31d.SHT31D(i2c)
tempcount = 0
loopcount = 0
while True:
    print("\nTemperature: %0.1f C" % sensor.temperature)
    print("Temperature: %0.1f F" % (sensor.temperature * 1.8 + 32))
    print("Humidity: %0.1f %%" % sensor.relative_humidity)
    tempcount = tempcount + sensor.temperature
    loopcount += 1
    time.sleep(2)
    # every 10 passes turn on the heater for 1 second
    if loopcount == 30:
        wifi.radio.stop_station()
        average = (tempcount / 30)
        print(average)
        print("Starting AP...")
        ssid = "{} C, {} F, {}% Wet".format(round(average, 1), round((average * 1.8 + 32), 1), round(sensor.relative_humidity, 1))
        print(ssid)
        wifi.radio.start_ap(ssid)
        loopcount = 0
        tempcount = 0
        sensor.heater = True
        print("Sensor Heater status =", sensor.heater)
        time.sleep(1)
        sensor.heater = False
        print("Sensor Heater status =", sensor.heater)

